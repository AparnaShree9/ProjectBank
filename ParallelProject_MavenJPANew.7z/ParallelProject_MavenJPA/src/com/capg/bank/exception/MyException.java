package com.capg.bank.exception;
public class MyException extends Exception{
	private String status= " Exception Occured";
	
	public MyException() {
		
	}
	
	public MyException(String status) {
		super(status);
		status = "This is the exception class";
	}
	
	public String getStatus() {
		return this.status;
	}

	@Override
	public String toString() {
		return "Myexception [status=" + status + "]";
	}
	
	
} 

