package com.capg.bank.test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capg.bank.beans.BankAccount;
import com.capg.bank.beans.Transaction;
import com.capg.bank.dao.BankDAOImp;
import com.capg.bank.exception.MyException;

public class BankTest {
BankDAOImp dao = null;
BankAccount bank1 = new BankAccount();
BankAccount bank2 = new BankAccount();

	@Before
	public void setUp() throws Exception {
		dao= new BankDAOImp();
	}

	@After
	public void tearDown() throws Exception {
		dao = null;
	}

	@Test
	public void testCreateAccount() throws MyException {
		
		bank1 = new BankAccount("Aparna","789456123159",20,"7894561234",1000.0,"Chennai");
		bank2 = new BankAccount("Shree","783589123159",21,"7878965234",1500.0,"Bhopal");
		
		
			int acc = dao.createAccount(bank1);           //Account Number and ATM pin are randomly getting generated in the DAO implementation class
			System.out.println(acc);
			System.out.println(bank1.getAtmPin());
			assertNotEquals(11111111, acc);
			
			int acc2 = dao.createAccount(bank2); 
			System.out.println(acc2);
			System.out.println(bank2.getAtmPin());
			assertNotEquals(11111111, acc2);
			
			
	}

	@Test
	public void testShowBalance() {
		try {
			double d = dao.showBalance(284826,1335);
			//assertEquals(1000, d, 0);
			assertNotNull(d);
		} catch (MyException e) {
			
			e.printStackTrace();
		}
		
	}

	@Test
	public void testDeposit() {
		try {
			double c = dao.deposit(284826, 20.0);
			//assertEquals(1020, c, 0);
			assertNotNull(c);
		} catch (MyException e) {
			
			e.printStackTrace();
		}
	}

	@Test
	public void testWithdraw() {
		try {
			double c=	dao.withdraw(337424,4666, 50.0);
			//assertEquals(1450, c, 0);
			assertNotNull(c);
		} catch (MyException e) {
			
			e.printStackTrace();
		}
	}
	

	@Test
	public void testFundTransfer() {
		try {
			double c=dao.fundTransfer(337424,284826,4666,100.0);
			assertNotNull("HAVE VALUE",c);
		} catch (MyException e) {
			
			e.printStackTrace();
		}
		
	}

	@Test
	public void testPrintTransactions() {
		 try {
			List<Transaction> printTransactions = dao.printTransactions(337424);
			assertNotNull(printTransactions);
		} catch (MyException e) {
			
			e.printStackTrace();
		}
	}

}
