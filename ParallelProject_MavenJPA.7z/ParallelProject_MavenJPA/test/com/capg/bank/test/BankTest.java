package com.capg.bank.test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capg.bank.beans.BankAccount;
import com.capg.bank.beans.Transaction;
import com.capg.bank.dao.BankDAOImp;
import com.capg.bank.exception.MyException;

public class BankTest {
BankDAOImp dao = null;
BankAccount b = new BankAccount();
BankAccount bank = new BankAccount();

	@Before
	public void setUp() throws Exception {
		dao= new BankDAOImp();
	}

	@After
	public void tearDown() throws Exception {
		dao = null;
	}

	@Test
	public void testCreateAccount() {
		
		b = new BankAccount("Aparna","789456123159",20,"7894561234",1000.0,"Chennai");
		bank = new BankAccount("Shree","783589123159",20,"7878965234",1500.0,"Bhopal");
		
		try {
			dao.createAccount(bank);
			assertNotEquals("invalid account", 111111111, bank.getAccountNumber());
			
		} catch (MyException e) {
			
			e.printStackTrace();
		}
		try {
			dao.createAccount(b);
		} catch (MyException e) {
			
			e.printStackTrace();
		}
		
	}

	@Test
	public void testShowBalance() {
		try {
			//dao.showBalance(173254,3416);
			double d = dao.showBalance(173254,3416);
			assertNotNull(d);
			
		} catch (MyException e) {
			
			e.printStackTrace();
		}
		
	}

	@Test
	public void testDeposit() {
		try {
			double c = dao.deposit(173254, 20.0);
			/*assertEquals(1020.0,);*/
			assertNotNull(c);
		} catch (MyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testWithdraw() {
		try {
			double c=	dao.withdraw(173254,3416, 20.0);
			/*assertEquals(1480.0, bank.getBalance());*/
			assertNotNull(c);
		} catch (MyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

	@Test
	public void testFundTransfer() {
		try {
			double c=dao.fundTransfer(173254,193131,3416,50.0);
			assertNotNull(c);
		} catch (MyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Test
	public void testPrintTransactions() {
		 try {
			List<Transaction> printTransactions = dao.printTransactions(173254);
			assertNotNull(printTransactions);
		} catch (MyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
