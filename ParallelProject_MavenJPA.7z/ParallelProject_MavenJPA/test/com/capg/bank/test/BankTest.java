package com.capg.bank.test;

import static org.junit.Assert.fail;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capg.bank.beans.BankAccount;
import com.capg.bank.dao.BankDAOImp;
import com.capg.bank.exception.MyException;

public class BankTest {
BankDAOImp dao = null;
	@Before
	public void setUp() throws Exception {
		dao= new BankDAOImp();
	}

	@After
	public void tearDown() throws Exception {
		dao = null;
	}

	@Test
	public void testCreateAccount() {
		
		BankAccount b = new BankAccount("Sita","789456123159",20,"7894561234",1000.0,"Chennai");
		BankAccount bank = new BankAccount("Ram","783589123159",20,"7878965234",1500.0,"Bhopal");
		
		try {
			dao.createAccount(bank);
		} catch (MyException e) {
			
			e.printStackTrace();
		}
		try {
			dao.createAccount(b);
		} catch (MyException e) {
			
			e.printStackTrace();
		}
		
	}

	@Test
	public void testShowBalance() {
	
	}

	@Test
	public void testDeposit() {
		fail("Not yet implemented");
	}

	@Test
	public void testWithdraw() {
		fail("Not yet implemented");
	}

	@Test
	public void testFundTransfer() {
		fail("Not yet implemented");
	}

	@Test
	public void testPrintTransactions() {
		fail("Not yet implemented");
	}

}
