package com.capg.bank.dao;

import java.util.List;
import java.util.Random;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceException;
import javax.persistence.Query;

import com.capg.bank.beans.BankAccount;
import com.capg.bank.beans.Transaction;
import com.capg.bank.exception.MyException;
import com.capgemini.jpa.utility.JPAUtil;

public class BankDAOImp implements IBankDAO {
	
	//BankAccount c = new BankAccount();
	
	private EntityManager entityManager=JPAUtil.getEntityManager();
	@Override
	public int createAccount(BankAccount b) throws MyException {
		EntityManager entityManager = null;
		try{
			entityManager=JPAUtil.getEntityManager();
			
			EntityTransaction transaction = entityManager.getTransaction();
			transaction.begin();
			
			Random rd1= new Random();
		    int accNum= 100000+ rd1.nextInt(99999);

			b.setAccountNumber(accNum);
			Random rd2= new Random();
		       int accPin= 1000+ rd2.nextInt(9999);
	      
			
			b.setAtmPin(accPin);
			 System.out.println("your PIN number is " + accPin );
			Transaction trans = new Transaction();
			trans.setBankAccount(b);
			trans.setTransactionAmount(b.getBalance());
			trans.setTransactionType("Deposited");
			entityManager.persist(trans);
			entityManager.persist(b);
			entityManager.getTransaction().commit();
			return accNum;

		}catch(PersistenceException e) {
			e.printStackTrace();
			
			throw new MyException(e.getMessage());
		}finally {
			entityManager.close();
			
		}
		
	}
	

	@Override
	public double showBalance(int accountNumber, int atmPin)throws MyException {
		boolean val= false;
		double bal=0.0;
			val=isValid(accountNumber,atmPin);
			
		try{
			if(val){
			entityManager=JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			BankAccount c = entityManager.find(BankAccount.class,accountNumber );
			bal= c.getBalance();
			return bal;
			}
			else {
				System.err.println("Wrong entry");
			}
			return bal;
		}catch(PersistenceException e) {
			e.printStackTrace();
		

			throw new MyException(e.getMessage());
		}finally {
			entityManager.close();
			
		}
	
	}
	private boolean isValid(int accountNumber, int atmPin) {
		boolean flag=false;
		entityManager=JPAUtil.getEntityManager();
		entityManager.getTransaction().begin();
		BankAccount b = entityManager.find(BankAccount.class,accountNumber);
		if((b.getAccountNumber()==accountNumber) && (b.getAtmPin()==atmPin)){
			
			flag= true;
			return flag;
		}
		entityManager.getTransaction().commit();
		return flag;
	}


	@Override
	public double deposit(int accountNumber, double depamt) throws MyException {
	try{	
		entityManager=JPAUtil.getEntityManager();
		entityManager.getTransaction().begin();
		double bal=0.0;
		boolean val= false;
		  val= isValid(accountNumber);
		BankAccount b = entityManager.find(BankAccount.class,accountNumber);
		if(val){
			bal = (b.getBalance()+depamt);
			b.setBalance(bal);
			 entityManager.merge(b);
			 Transaction trans = new Transaction();
				trans.setTransactionAmount(depamt);
				trans.setTransactionType("Deposited");
				trans.setBankAccount(b);
				entityManager.persist(trans);
			entityManager.getTransaction().commit();
		return (b.getBalance());
			
		}
		else{
			
			System.err.println("Can't process the Transaction");
		}
		return (b.getBalance());
	}catch(PersistenceException e) {
		e.printStackTrace();
		

		throw new MyException(e.getMessage());
	}finally {
		entityManager.close();
		
	}
	}

	private boolean isValid(int accountNumber) {
		boolean flag=false;
		entityManager=JPAUtil.getEntityManager();
		entityManager.getTransaction().begin();
		BankAccount b = entityManager.find(BankAccount.class,accountNumber);
		if((b.getAccountNumber()==accountNumber)){
			
			flag= true;
			return flag;
		}
		entityManager.getTransaction().commit();
		return flag;
	}


	@Override
	public double withdraw(int accountNumber, int atmPin, double widAmt)
			throws MyException {
		try{
			boolean val= false;
			double bal=0.0;

    		entityManager=JPAUtil.getEntityManager();
    		entityManager.getTransaction().begin();

    		BankAccount b = entityManager.find(BankAccount.class,accountNumber);
		    val=isValid(accountNumber,atmPin);
		    	if(val){
		    		
			          if(b.getBalance()>widAmt){
			        	  bal = (b.getBalance()-widAmt);
			        	  b.setBalance(bal);
			        	  //System.out.println(b.getAccount_balance());
			        	  Transaction trans = new Transaction();
							trans.setTransactionAmount(widAmt);
							trans.setTransactionType("Withdrawn");
							trans.setBankAccount(b);
							entityManager.persist(trans);
			        	  entityManager.merge(b);
			        	  entityManager.getTransaction().commit();
			          }else{
			        	  System.err.println("Insufficient Amount");
			          }
			      return b.getBalance();   
		    	
		    	}else{
		    		System.err.println("Can't process the Transaction");
		    		
		    	}
		   return b.getBalance();
	}catch(PersistenceException e) {
		e.printStackTrace();
		

		throw new MyException(e.getMessage());
	}finally {
		entityManager.close();
		
	}
}


	@Override
	public double fundTransfer(int account_Number, int account_Number2,
			int pin_number, double tAmt) throws MyException {
		
		try{
		double bal=0.0;
		double bal2 =0.0;
		boolean val1= false;
		boolean val2= false;
		val1=isValid(account_Number,pin_number);
	    val2=isValid(account_Number);
		entityManager=JPAUtil.getEntityManager();
		entityManager.getTransaction().begin();

		BankAccount b = entityManager.find(BankAccount.class,account_Number);
		BankAccount c = entityManager.find(BankAccount.class,account_Number2);
		if(val1){
			if(val2){
				if(b.getBalance()>tAmt){
					bal = (b.getBalance()-tAmt);
					b.setBalance(bal);
					 Transaction trans = new Transaction();
						trans.setTransactionAmount(tAmt);
						trans.setTransactionType("Transferred to "+ c.getAccountNumber());
						trans.setBankAccount(b);
						entityManager.persist(trans);
					entityManager.merge(b);
					
					//entityManager.getTransaction().commit();
			 
					bal2 = (c.getBalance()+tAmt);
					c.setBalance(bal2);
					entityManager.merge(c);
					 Transaction trans1 = new Transaction();
						trans1.setTransactionAmount(tAmt);
						trans1.setTransactionType("Received from "+b.getAccountNumber());
						trans1.setBankAccount(c);
						entityManager.persist(trans1);
					entityManager.getTransaction().commit();
					return b.getBalance(); 
				}else{
					System.err.println("Insufficient Amount");
					}
			}else{
				System.out.println("wrong beneficiary's details");
				}
		}else{
			System.out.println("Entering wrong Details");
		}
		 return b.getBalance();   
	    
		}catch(PersistenceException e) {
			e.printStackTrace();
			

			throw new MyException(e.getMessage());
		}finally {
			entityManager.close();
			
		}
	}


	@Override
	public List<Transaction> printTransactions(int accountNumber) throws MyException {
		try{
			entityManager=JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
	    Query query=entityManager.createNativeQuery("select*from bank_tranaction where account_Number=?",Transaction.class);
		query.setParameter(1,accountNumber);
		
	    List<Transaction> transList = query.getResultList();
	    return transList;
		}catch(PersistenceException e) {
			e.printStackTrace();
			

			throw new MyException(e.getMessage());
		}finally {
			entityManager.close();
			
		}
	}
}
