package com.capg.bank.dao;
import java.util.List;


import com.capg.bank.exception.MyException;
import com.capg.bank.beans.BankAccount;
import com.capg.bank.beans.Transaction;
import com.capg.bank.exception.MyException;

public interface IBankDAO {
	
	 public int createAccount(BankAccount b) throws MyException;
	 public double showBalance(int accountNumber, int atmPin ) throws MyException;
	 public double deposit(int accountNumber,double depamt) throws MyException;
	 
	 public double withdraw(int accountNumber,int atmPin, double widAmt) throws MyException;
	 public double fundTransfer(int accountNumber,int accountNumber2,int atmPin,double tAmt) throws MyException;
	 public List<Transaction> printTransactions(int accountNumber) throws MyException;
}
