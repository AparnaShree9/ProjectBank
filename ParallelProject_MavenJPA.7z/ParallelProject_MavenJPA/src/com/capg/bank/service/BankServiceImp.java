package com.capg.bank.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capg.bank.beans.BankAccount;
import com.capg.bank.beans.Transaction;
import com.capg.bank.dao.BankDAOImp;
import com.capg.bank.dao.IBankDAO;
import com.capg.bank.exception.MyException;

public class BankServiceImp implements IBankService {
	
	IBankDAO dao = new BankDAOImp();
	
public boolean validateName	(String customerName) throws MyException{
	Pattern name = Pattern.compile("^[A-Z][A-Za-z\\s]*$");
	
        Matcher match = name.matcher(customerName);
        if(match.matches()){
            return true;
        }
        return false;
    }
public boolean validateID(String adharCardNumber ) throws MyException{
	Pattern id = Pattern.compile("\\d{12}");
	
        Matcher match = id.matcher(adharCardNumber);
        if(match.matches()){
            return true;
        }
        return false;
    }
	
public boolean validateAge(int birthdate) throws MyException{
	if(birthdate>12){
		return true;
	}
	return false;

}

public boolean validateAdd(StringBuffer customerAddress){
	
	Pattern addr = Pattern.compile("[A-Za-z0-9,]+");
	
    Matcher match = addr.matcher(customerAddress);
    if(match.matches()){
        return true;
    }
    return false;
	}

public boolean validatenum(String mobileNumber) throws MyException{
	Pattern num = Pattern.compile("\\d{10}");
	
        Matcher match = num.matcher(mobileNumber);
        if(match.matches()){
            return true;
        }
        return false;
    }

public boolean validateAmt(double balance) throws MyException{
	if(balance>=500){
		return true;
	}
	return false;

}

	@Override
	public int createAccount(BankAccount b) throws MyException {
		
		return dao.createAccount(b);
	}
	@Override
	public double showBalance(int accountNumber, int atmPin)throws MyException {
			
		
		return dao.showBalance(accountNumber, atmPin);
	}
	@Override
	public double deposit(int accountNumber, double depamt) throws MyException {
		
		return dao.deposit(accountNumber, depamt);
	}
	@Override
	public double withdraw(int accountNumber, int atmPin, double widAmt)
			throws MyException {
		
		return dao.withdraw(accountNumber, atmPin, widAmt);
	}
	@Override
	public double fundTransfer(int accountNumber, int accountNumber2,
			int atmPin, double tAmt) throws MyException {
		
		return dao.fundTransfer(accountNumber, accountNumber2, atmPin, tAmt);
	}
	@Override
	public List<Transaction> printTransactions(int accountNumber)
			throws MyException {
		
		return dao.printTransactions(accountNumber);
	}
	

	
}
