package com.capg.bank.beans;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.ForeignKey;


@Entity
@Table(name="bank_transaction")
public class Transaction {	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="serial_Number")
	private int serialNumber;
	
	/*@Temporal(TemporalType.DATE)
	private Date transactionDate;*/
	
	@Column(name="transaction_amount")
	private double transactionAmount;
	
	@Column(name="transaction_type")
	private String transactionType;
	
	@ManyToOne
	@JoinColumn(name="account_number")
	private BankAccount bankAccount;
	
	public int getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(int serialNumber) {
		serialNumber = serialNumber;
	}
	/*public Date getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}*/
	public double getTransactionAmount() {
		return transactionAmount;
	}
	public void setTransactionAmount(double transactionAmount) {
		this.transactionAmount = transactionAmount;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public BankAccount getBankAccount() {
		return bankAccount;
	}
	public void setBankAccount(BankAccount bankAccount) {
		this.bankAccount = bankAccount;
	}
	
	@Override
	public String toString() {
		return  "\n transactionAmount :" + transactionAmount
				+ "\n transactionType :" + transactionType
				;
	}
	
	
	}
