package com.capg.bank.beans;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.ForeignKey;


@Entity
@Table(name="bank_tranaction")
public class Transaction {	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int SerialNumber;
	/*@Temporal(TemporalType.DATE)
	private Date transactionDate;*/
	private double transactionAmount;
	private String transactionType;
	@ManyToOne
	@JoinColumn(name="account_Number")
	private BankAccount bankAccount;
	public int getSerialNumber() {
		return SerialNumber;
	}
	public void setSerialNumber(int serialNumber) {
		SerialNumber = serialNumber;
	}
	/*public Date getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}*/
	public double getTransactionAmount() {
		return transactionAmount;
	}
	public void setTransactionAmount(double transactionAmount) {
		this.transactionAmount = transactionAmount;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public BankAccount getBankAccount() {
		return bankAccount;
	}
	public void setBankAccount(BankAccount bankAccount) {
		this.bankAccount = bankAccount;
	}
	/*@Override
	public String toString() {
		return "Transaction [SerialNumber=" + SerialNumber
				+ ", transactionDate=" + transactionDate
				+ ", transactionAmount=" + transactionAmount
				+ ", transactionType=" + transactionType + ", bankAccount="
				+ bankAccount + "]";
	}	*/
	
	
	
	




	}
