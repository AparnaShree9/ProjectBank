package com.capg.bank.beans;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

@Entity
public class BankAccount {
	
	@Id
	@Column(name="account_number")
	private int accountNumber;
	@NotNull
	@Column(name="customer_name")
	private String customerName;
	@NotNull
	@Column(name="adharcard_number")
	private String adharCardNumber;
	/*@NotNull
	@Temporal(TemporalType.DATE)
	private Date birthdate;*/
	@NotNull
	private int age;
	@NotNull
	@Column(name="mobile_number")
	private String mobileNumber;
	@NotNull
	private double balance;
	@NotNull
	@Column(name="customer_address")
	private String customerAddress;
	@NotNull
	@Column(name="atm_pin")
	private int atmPin;
	@OneToMany(mappedBy="bankAccount", cascade=CascadeType.ALL)	
	private List<Transaction> transactionList=new ArrayList<>();
	
	
	public BankAccount(){}


/*	public BankAccount(String customerName, String adharCardNumber,
			Date birthdate, String mobileNumber, double balance,
			StringBuffer customerAddress) {
		super();
		this.customerName = customerName;
		this.adharCardNumber = adharCardNumber;
		this.birthdate = birthdate;
		this.mobileNumber = mobileNumber;
		this.balance = balance;
		this.customerAddress = customerAddress;
	}*/


	public int getAccountNumber() {
		return accountNumber;
	}


	public BankAccount(String customerName, String adharCardNumber,
			int birthdate, String mobileNumber, double balance,
			String customerAddress) {
		super();
		this.customerName = customerName;
		this.adharCardNumber = adharCardNumber;
		this.age = birthdate;
		this.mobileNumber = mobileNumber;
		this.balance = balance;
		this.customerAddress = customerAddress;
	}


	public int getBirthdate() {
		return age;
	}


	public void setBirthdate(int birthdate) {
		this.age = birthdate;
	}


	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}


	public String getCustomerName() {
		return customerName;
	}


	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}


	public String getAdharCardNumber() {
		return adharCardNumber;
	}


	public void setAdharCardNumber(String adharCardNumber) {
		this.adharCardNumber = adharCardNumber;
	}


	/*public Date getBirthdate() {
		return birthdate;
	}


	public void setBirthdate(Date birthdate) {
		this.birthdate = birthdate;
	}
*/

	public String getMobileNumber() {
		return mobileNumber;
	}


	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}


	public double getBalance() {
		return balance;
	}


	public void setBalance(double balance) {
		this.balance = balance;
	}


	public String getCustomerAddress() {
		return customerAddress;
	}


	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}


	public int getAtmPin() {
		return atmPin;
	}


	public void setAtmPin(int atmPin) {
		this.atmPin = atmPin;
	}


	public List<Transaction> getTransactionList() {
		return transactionList;
	}


	public void setTransactionList(List<Transaction> transactionList) {
		this.transactionList = transactionList;
	}


	/*@Override
	public String toString() {
		return "BankAccount [accountNumber=" + accountNumber
				+ ", customerName=" + customerName + ", adharCardNumber="
				+ adharCardNumber + ", birthdate=" + birthdate
				+ ", mobileNumber=" + mobileNumber + ", balance=" + balance
				+ ", customerAddress=" + customerAddress + ", atmPin=" + atmPin
				+ ", transactionList=" + transactionList + "]";
	}*/
	
}	
	
