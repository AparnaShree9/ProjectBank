package com.capg.bank.ui;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capg.bank.beans.BankAccount;
import com.capg.bank.beans.Transaction;
import com.capg.bank.exception.MyException;
import com.capg.bank.service.BankServiceImp;

public class Client {
	  private static Scanner sc = new Scanner(System.in);
     private static BankAccount bank = new BankAccount();
      private static BankServiceImp service = new BankServiceImp();
	public static void main(String[] args) throws MyException
		 {
	
		
        System.out.println("---------Welcome to XYZ bank-----------");
         while (true){
        System.out.println("----------------------------------------");
		System.out.println("Choose the services you want to avail");
		System.out.println("1.Create Account");
		System.out.println("2.Show Balance");
		System.out.println("3.Deposit");
		System.out.println("4.Withdraw");
		System.out.println("5.Fund Transfer");
		System.out.println("6.Print Transactions");
		System.out.println("7.Exit");
		System.out.print("Enter your choice :");
		        int n = sc.nextInt();
		System.out.println("*******************************************");        
		   switch (n) {
		case 1:
			Scanner sc1 = new Scanner(System.in);
		    System.out.print("Enter your name:");
		    String cname = sc1.nextLine();
		    boolean isTrue = service.validateName(cname);
			   boolean validname;
			   String cname1;
			   if(!isTrue){
				   do{
					   System.err.println("Enter your name as per your ID with fist letter capital");
					   System.out.print("Enter your name:");
					   cname = sc1.nextLine();
					   validname = service.validateName(cname);
				   }while(!validname);
				      cname1 = cname;
				   }else 
					   cname1 = cname;
		    System.out.print("Give your permanent government ID (Adhaar No.): ");
			String cid = sc.next();
			 boolean isTrue1 = service.validateID(cid);
			   boolean validid;
			   String cid1;
			   if(!isTrue1){
				   do{
					   System.err.println("Enter your 12 digit Adhaar number");
					   System.out.print("Give your permanent government ID (Adhaar No.): ");
					   cid = sc.next();
					   validid = service.validateID(cid);
				   }while(!validid);
				   cid1= cid;
				   }else 
					   cid1= cid;
			   
			System.out.print("enter your age:");
			int age = sc.nextInt();
			boolean isTrue2=service.validateAge(age);
			  boolean validage;
			  int age1;
			  if(!isTrue2){
				  do{
					  System.err.println("The age should be more than 12");
					  System.out.print("Re-enter your age : ");
					  age =sc.nextInt();
					  validage = service.validateAge(age);  
				  }while(!validage);
					 age1 = age;
			  }else
				  	age1 = age;
			   
			  Scanner sc2 = new Scanner(System.in);  
			System.out.print("Enter your address :");
			 String w = sc2.nextLine();
		    boolean isTrue3=service.validateAdd(w);
			  boolean validcity;
			  String city;
			  if(!isTrue3){
				  do{
					  System.err.println("Enter correct address (alphabets,numbers & ,)");
					  System.out.println("Re-enter your address :");
					   w = sc2.nextLine();
					  validcity = service.validateAdd(w);  
				  }while(!validcity);
				       city = w;
			  }else 
				  city = w;
	        

		    System.out.print("Enter your mobile number : ");
			String number = sc.next();
			 boolean isTrue4=service.validatenum(number);
			    boolean validnum;
			  String num;
			  if(!isTrue4){
				  do{
					  System.err.println("Enter valid number");
					  System.out.print("Re-enter your number :");
					  number =sc.next();
					  validnum = service.validatenum(number);  
				  }while(!validnum);
					 num= number;
			  }else
				     num= number;
			
	        System.out.print("Enter the minimum balance for your account (minimum amount limit is 500): ");
	       
	        double amt =sc.nextDouble();
	        boolean isTrue5=service.validateAmt(amt);
			  boolean validamt;
			  double amt1;
			  if(!isTrue5){
				  do{
					  System.err.println("The minimum amount limit is 500");
					  System.out.print("Re-enter amount :");
					  amt =sc.nextDouble();
					  validamt = service.validateAmt(amt);  
				  }while(!validamt);
					 amt1=amt;
			  }else
				  amt1=amt;
			
	        BankAccount bank = new BankAccount(cname1,cid1,age1,num,amt1,city);
	       
	        int acc = service.createAccount(bank);
	        System.out.println("Congratulations ! Your account has been created");
	        System.out.println("your Account number is :" + acc);
	        System.out.println("your Pin number is :" + bank.getAtmPin());
		       break;

		case 2:

 	       System.out.print("Enter your account number :");
		          int accNum= sc.nextInt();
		          
		          System.out.print("Enter your PIN  :");
		          int pn= sc.nextInt();
		try{
			
		           
		       double bal=service.showBalance(accNum, pn);
		       System.out.println("Your account balance is"+bal);
	      
 	       }catch(MyException exp){
 		
 		       System.out.println("It's an Error message"+exp.getMessage());
 	           } 

			
			break;
		case 3:
			System.out.print("Enter your account number  :");
        	int acNum = sc.nextInt();
        	
        	System.out.print("Enter the amount to be deposited  :");
            double depamt = sc.nextDouble();
            try{
            double newbal =service.deposit(acNum, depamt);
        	System.out.println("your current balance is: "+ newbal);
            
            }catch(MyException exp){
         		
  		       System.out.println("It's an Error message"+exp.getMessage());
  	           } 
        	break;
		
		
		case 4:
			System.out.print("Enter your account number   :");
	        int accNum1= sc.nextInt();
	          
	        System.out.print("Enter your PIN  :");
	        int pn1= sc.nextInt();
	       
	        System.out.print("Enter the amount you want to withdraw");
	        double widAmt= sc.nextDouble();
      	
	        try{
	        double newbal2=service.withdraw(accNum1, pn1, widAmt);
	        System.out.println("your current balance is: "+ newbal2);
		  
	        }catch(MyException exp){
		 		
 		       System.out.println("It's an Error message"+exp.getMessage());
 	           } 
			break;
		case 5:
			try{
            	System.out.print("Enter your account number  :");
				int accnumf = sc.nextInt();
				System.out.print("Enter your PIN  :");
				int fpin = sc.nextInt();
				
			    System.out.print("Enter beneficiary's account number   :");
				int accnums = sc.nextInt();
				
			    System.out.print("Enter the amount to be transferred   :");
			    double tAmt = sc.nextDouble();
			    double newbal3 = service.fundTransfer(accnumf, accnums, fpin, tAmt);
			    System.out.println("you transferred Rs "+tAmt+" your current balance is: "+ newbal3);        
            	
			
			
			}catch(MyException exp){
            		
            		System.out.println("It's an Error message"+exp.getMessage());
            	} 
			break;
		case 6:
			System.out.print("Enter your account number  :");
			int accnumf = sc.nextInt();
    		try{
			List<Transaction>empL = service.printTransactions( accnumf);
    		System.out.println("Transaction Details :");
    		showCustomer(empL);
    		 }catch(MyException exp){
    		 		
   		       System.out.println("It's an Error message"+exp.getMessage());
   	           } 
			break;
			
			
		default:
			
			break;
		
}
}
}
	private static void showCustomer(List<Transaction> empL) {
		Iterator<Transaction> iterator = empL.iterator();
		while(iterator.hasNext()){
			System.out.println(iterator.next());
		}
	}
	
}